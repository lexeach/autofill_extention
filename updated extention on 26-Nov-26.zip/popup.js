const API = "https://autofill-payment-backend-fork.onrender.com";
const $ = (id) => document.getElementById(id);
let profiles = [];

function setStatus(message, isError=false) {
  $("status").textContent = message || "";
  $("status").className = isError ? "error" : "";
}
function showLoggedOut() {
  $("loginView").classList.remove("hidden");
  $("profilesView").classList.add("hidden");
}
function showLoggedIn() {
  $("loginView").classList.add("hidden");
  $("profilesView").classList.remove("hidden");
}
async function apiRequest(path, token, options={}) {
  const response = await fetch(API + path, {
    ...options,
    headers: {
      "Content-Type": "application/json",
      ...(token ? {Authorization: `Bearer ${token}`} : {}),
      ...(options.headers || {})
    }
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || `Request failed (${response.status})`);
  return data;
}
async function loadProfiles(token) {
  const [me, result] = await Promise.all([
    apiRequest("/api/auth/me", token),
    apiRequest("/api/profiles", token)
  ]);
  // Only activated profiles should be available inside the extension.
  // The dashboard can still list inactive profiles so the user can activate them there.
  const allProfiles = Array.isArray(result.profiles) ? result.profiles : [];
  profiles = allProfiles.filter(profile => profile.is_active === true);
  $("accountLabel").textContent = `Signed in: ${me.user?.email || "your account"} · ${profiles.length} activated profile(s)`;
  const select = $("profileSelect");
  select.replaceChildren();
  const {selectedProfileId} = await chrome.storage.local.get("selectedProfileId");
  if (!profiles.length) {
    const option = document.createElement("option");
    option.value = "";
    option.textContent = "No activated profiles — activate one in dashboard";
    select.append(option);
    $("fillBtn").disabled = true;
    // Do not keep a previously selected inactive profile ID.
    await chrome.storage.local.remove("selectedProfileId");
  } else {
    for (const profile of profiles) {
      const option = document.createElement("option");
      option.value = profile.id;
      option.textContent = profile.name || "Unnamed profile";
      select.append(option);
    }
    if (selectedProfileId && profiles.some(p => p.id === selectedProfileId)) {
      select.value = selectedProfileId;
    } else {
      select.selectedIndex = 0;
      await chrome.storage.local.set({selectedProfileId: select.value});
    }
    $("fillBtn").disabled = false;
  }
  showLoggedIn();
}
async function boot() {
  const {token} = await chrome.storage.local.get("token");
  if (!token) return showLoggedOut();
  try {
    await loadProfiles(token);
    setStatus("");
  } catch (e) {
    await chrome.storage.local.remove(["token", "selectedProfileId"]);
    showLoggedOut();
    setStatus("Please sign in again. " + e.message, true);
  }
}
$("loginForm").addEventListener("submit", async (event) => {
  event.preventDefault();
  $("loginBtn").disabled = true;
  setStatus("Signing in…");
  try {
    const data = await apiRequest("/api/auth/login", null, {
      method: "POST",
      body: JSON.stringify({email: $("email").value.trim(), password: $("password").value})
    });
    await chrome.storage.local.set({token: data.token});
    $("password").value = "";
    await loadProfiles(data.token);
    setStatus(profiles.length ? "Select a profile, then click Fill current page." : "Create a profile in the dashboard first.");
  } catch (e) {
    setStatus(e.message, true);
  } finally {
    $("loginBtn").disabled = false;
  }
});
$("profileSelect").addEventListener("change", async () => {
  await chrome.storage.local.set({selectedProfileId: $("profileSelect").value});
});
$("refreshBtn").addEventListener("click", async () => {
  $("refreshBtn").disabled = true;
  setStatus("Refreshing profiles…");
  try {
    const {token} = await chrome.storage.local.get("token");
    await loadProfiles(token);
    setStatus("Profiles refreshed.");
  } catch (e) { setStatus(e.message, true); }
  finally { $("refreshBtn").disabled = false; }
});
$("logoutBtn").addEventListener("click", async () => {
  await chrome.storage.local.remove(["token", "selectedProfileId"]);
  profiles = [];
  showLoggedOut();
  setStatus("Signed out.");
});
$("fillBtn").addEventListener("click", async () => {
  const profile = profiles.find(p => p.id === $("profileSelect").value);
  if (!profile) return setStatus("Choose a profile first.", true);
  const [tab] = await chrome.tabs.query({active:true,currentWindow:true});
  if (!tab?.id || !tab.url || /^(chrome|edge|about|chrome-extension):/.test(tab.url)) {
    return setStatus("Open the target form page first, then click the extension.", true);
  }
  const fields = profile.fields && typeof profile.fields === "object" ? profile.fields : {};
  if (!Object.values(fields).some(v => String(v ?? "").trim())) {
    return setStatus("This profile has no field values. Edit it in the dashboard first.", true);
  }
  $("fillBtn").disabled = true;
  setStatus(`Filling “${profile.name}”…`);
  try {
    const results = await chrome.scripting.executeScript({
      target: {tabId: tab.id, allFrames: true},
      func: autofillFromProfile,
      args: [fields]
    });
    const filled = results.reduce((n, r) => n + (r.result?.filled || 0), 0);
    setStatus(`Finished. ${filled} field(s) filled across accessible page frames. Please review all values before submitting the form.`);
  } catch (e) {
    setStatus("Could not fill this page: " + e.message, true);
  } finally { $("fillBtn").disabled = false; }
});

// Runs in the target page. It uses profile keys rather than hardcoded personal data.
async function autofillFromProfile(fields) {
  const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
  const normalize = s => String(s || "").toLowerCase().replace(/[^a-z0-9]/g, "");
  const aliases = {
    firstName:["firstname","first_name","givenname"], middleName:["middlename","middle_name"], lastName:["lastname","last_name","surname"],
    gender:["gender","sex"], nationality:["nationality","citizenship"], fatherName:["fathername","father_name","fathersname"],
    motherName:["mothername","mother_name","mothersname"], maritalStatus:["maritalstatus","marital_status"], dob:["dob","dateofbirth","birthdate"],
    panNo:["panno","pan","pannumber"], aadhaarNo:["aadhaarno","aadhaar","aadhaarnumber","adhar","adharno","uid"], category:["category","reservationcategory"],
    email:["email","emailaddress"], mobileNo:["mobileno","mobile","mobilenumber","phone","phonenumber"], stdCode:["stdcode","areacode"],
    phoneNo:["phoneno","landline"], bankName:["bankname","bank"], branchName:["branchname","branch"], ifscCode:["ifsccode","ifsc"],
    bankAccountNo:["bankaccountno","accountnumber","bankaccountnumber"], addJointApplicant:["addjointapplicant","jointapplicant"],
    housePlotNo:["houseplotno","houseno","plotno","house"], streetRoad:["streetroad","street","road","addressline1"],
    areaLocality:["arealocality","locality","area"], townVillage:["townvillage","town","village","city"], state:["state"],
    district:["district"], pincode:["pincode","postalcode","zipcode"], region:["region"]
  };
  const getAliases = key => [key, ...(aliases[key] || [])].map(normalize);
  const allElements = () => Array.from(document.querySelectorAll("input, textarea, select"));
  const labelText = el => {
    const pieces = [];
    if (el.labels) pieces.push(...Array.from(el.labels).map(l => l.innerText || l.textContent || ""));
    const parent = el.closest("label");
    if (parent) pieces.push(parent.innerText || parent.textContent || "");
    if (el.getAttribute("aria-label")) pieces.push(el.getAttribute("aria-label"));
    const parentText = el.closest("td, .form-group, .row, .col, .control-group");
    if (parentText) pieces.push((parentText.innerText || "").slice(0, 180));
    return normalize(pieces.join(" "));
  };
  const elementKeyText = el => normalize([
    el.name, el.id, el.placeholder, el.getAttribute("aria-label"),
    el.getAttribute("autocomplete"), el.getAttribute("formcontrolname")
  ].filter(Boolean).join(" "));
  const setNativeValue = (el, value) => {
    const proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype :
      el instanceof HTMLSelectElement ? HTMLSelectElement.prototype : HTMLInputElement.prototype;
    const desc = Object.getOwnPropertyDescriptor(proto, "value");
    if (desc?.set) desc.set.call(el, value); else el.value = value;
    el.dispatchEvent(new Event("input", {bubbles:true}));
    el.dispatchEvent(new Event("change", {bubbles:true}));
  };
  const selectOption = (el, value) => {
    if (!el || el.disabled) return false;
    const target = normalize(value);
    const options = Array.from(el.options || []);
    const match = options.find(o => normalize(o.value) === target) ||
      options.find(o => normalize(o.textContent) === target) ||
      options.find(o => target.length > 2 && (normalize(o.textContent).includes(target) || target.includes(normalize(o.textContent))));
    if (!match) return false;
    el.focus();
    el.value = match.value;
    el.dispatchEvent(new Event("input", {bubbles:true}));
    el.dispatchEvent(new Event("change", {bubbles:true}));
    el.blur();
    return true;
  };
  const entries = Object.entries(fields || {}).filter(([k,v]) => String(v ?? "").trim() !== "");
  let filled = 0;
  const used = new Set();
  const getSelect = key => {
    const aliasesForKey = getAliases(key);
    const candidates = allElements().filter(el => el.tagName === "SELECT" && !el.disabled &&
      aliasesForKey.some(a => a.length > 2 && (elementKeyText(el).includes(a) || labelText(el).includes(a))));
    candidates.sort((a,b) => {
      const score = el => Math.max(...aliasesForKey.map(a => elementKeyText(el).includes(a) ? a.length + 10 : labelText(el).includes(a) ? a.length : 0));
      return score(b) - score(a);
    });
    return candidates[0];
  };

  // 1) State must be selected first so the DDA form can rebuild its District options.
  const stateEntry = entries.find(([k]) => getAliases(k).includes("state"));
  if (stateEntry) {
    const stateSelect = getSelect("state");
    if (stateSelect && selectOption(stateSelect, stateEntry[1])) {
      used.add(stateSelect); filled++;
      // Allow asynchronous onchange/AJAX handlers to populate the dependent District list.
      const districtSelectBefore = getSelect("district");
      const beforeOptions = districtSelectBefore ? districtSelectBefore.options.length : 0;
      for (let i = 0; i < 40; i++) {
        await sleep(150);
        const districtSelect = getSelect("district");
        if (districtSelect && !districtSelect.disabled && districtSelect.options.length > 1 &&
            (districtSelect.options.length !== beforeOptions ||
             !/select district|select|choose/i.test(districtSelect.options[0]?.textContent || ""))) break;
      }
    }
  }

  // 2) District after dependent options have had time to load.
  const districtEntry = entries.find(([k]) => getAliases(k).includes("district"));
  if (districtEntry) {
    let districtSelect = getSelect("district");
    for (let i = 0; districtSelect && (districtSelect.disabled || districtSelect.options.length <= 1) && i < 30; i++) {
      await sleep(150);
      districtSelect = getSelect("district");
    }
    if (districtSelect && selectOption(districtSelect, districtEntry[1])) {
      used.add(districtSelect); filled++;
    }
  }

  // 3) DDA Region radio group: map the saved display text to the form's
  // actual radio values (Delhi=1, Outside Delhi=2), then select by name/value.
  const regionEntry = entries.find(([k]) => getAliases(k).includes("region"));
  if (regionEntry) {
    const wanted = normalize(regionEntry[1]);
    const regionValueMap = {
      delhi: "1",
      outsidedelhi: "2",
      outside: "2",
      "1": "1",
      "2": "2"
    };
    const mappedRegion = regionValueMap[wanted] || String(regionEntry[1]).trim();
    const regionRadios = Array.from(document.querySelectorAll('input[type="radio"][name="region"]'));
    const targetRadio = regionRadios.find(r => normalize(r.value) === normalize(mappedRegion));
    if (targetRadio) {
      targetRadio.click();
      targetRadio.checked = true;
      targetRadio.dispatchEvent(new Event("input", { bubbles: true }));
      targetRadio.dispatchEvent(new Event("change", { bubbles: true }));
      used.add(targetRadio);
      filled++;
    }
  }

  // Fill all remaining fields using their keys/labels.
  for (const [key, rawValue] of entries) {
    const keyNorm = normalize(key);
    if (["state","district","region"].includes(keyNorm)) continue;
    const value = String(rawValue);
    const keyAliases = getAliases(key);
    const elements = allElements();
    let candidates = elements.filter(el => {
      if (used.has(el) || el.disabled || el.readOnly || ["hidden","submit","button","reset","file","image"].includes((el.type||"").toLowerCase())) return false;
      const meta = elementKeyText(el), labels = labelText(el);
      return keyAliases.some(a => a.length > 2 && (meta.includes(a) || labels.includes(a)));
    });
    candidates.sort((a,b) => {
      const score = el => {
        const m = elementKeyText(el), l = labelText(el);
        return Math.max(...keyAliases.map(a => Math.max(m.includes(a) ? a.length + 10 : 0, l.includes(a) ? a.length : 0)));
      };
      return score(b)-score(a);
    });
    const el = candidates[0];
    if (!el) continue;
    const tag = el.tagName.toLowerCase(), type = (el.type || "").toLowerCase();
    if (type === "radio") {
      const group = elements.filter(x => x.type === "radio" && x.name && x.name === el.name);
      // DDA gender radios use codes M/F/T while dashboard profiles store
      // readable values Male/Female/Transgender.
      const genderValueMap = {
        male: "M", m: "M",
        female: "F", f: "F",
        transgender: "T", t: "T"
      };
      const requested = normalize(value);
      const mappedValue = keyNorm === "gender"
        ? (genderValueMap[requested] || String(value).trim())
        : String(value).trim();
      const targetCode = normalize(mappedValue);
      const radio = group.find(x => normalize(x.value) === targetCode);
      if (radio) {
        // Use the actual radio input value, not the shared parent/container text.
        radio.click();
        radio.checked = true;
        radio.dispatchEvent(new Event("input", { bubbles: true }));
        radio.dispatchEvent(new Event("change", { bubbles: true }));
        used.add(radio);
        filled++;
      }
      continue;
    }
    if (type === "checkbox") {
      const yes = /^(yes|true|1|on|checked)$/i.test(value);
      if (el.checked !== yes) el.click();
      el.dispatchEvent(new Event("change",{bubbles:true})); used.add(el); filled++; continue;
    }
    if (tag === "select") {
      if (selectOption(el, value)) { used.add(el); filled++; }
      continue;
    }
    if (type === "date") {
      const d = value.match(/^\d{4}-\d{2}-\d{2}$/) ? value : "";
      if (!d) continue;
      setNativeValue(el, d); el.focus(); el.blur(); used.add(el); filled++; continue;
    }
    el.focus(); setNativeValue(el, value); el.blur(); used.add(el); filled++;
  }
  // DDA Declaration acknowledgement is not usually part of profile data.
  // Tick only the checkbox whose own label/context is clearly the declaration acknowledgement.
  const declarationCheckbox = Array.from(document.querySelectorAll('input[type="checkbox"]')).find(cb => {
    const own = normalize([
      cb.id, cb.name, cb.value, cb.getAttribute('aria-label'),
      ...(cb.labels ? Array.from(cb.labels).map(l => l.innerText || l.textContent || '') : []),
      cb.parentElement?.innerText || ''
    ].join(' '));
    let context = own;
    let node = cb.parentElement;
    for (let i = 0; node && i < 4; i++, node = node.parentElement) {
      const t = normalize(node.innerText || node.textContent || '');
      if (t.includes('declaration') && (t.includes('acknowledge') || t.includes('true') || t.includes('informationgivenabove'))) {
        context = t;
        break;
      }
    }
    return (own.includes('acknowledge') || own.includes('declaration')) &&
      (context.includes('declaration') || context.includes('acknowledge'));
  });
  if (declarationCheckbox && !declarationCheckbox.checked) {
    declarationCheckbox.click();
    declarationCheckbox.checked = true;
    declarationCheckbox.dispatchEvent(new Event('input', {bubbles:true}));
    declarationCheckbox.dispatchEvent(new Event('change', {bubbles:true}));
    filled++;
  }
  return {filled};
}
document.addEventListener("DOMContentLoaded", boot);
